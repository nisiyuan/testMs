export const getShowWrongMsg = state => state.showWrongMsg
export const getUserInfo = state => state.userInfo
export const getWrongMsg = state => state.wrongMsg
export const getIsLogin = state => state.isLogin
