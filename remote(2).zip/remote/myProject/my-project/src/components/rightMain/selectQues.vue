<template>
  <div id="selectQues" class="selectQues">
      选题
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  data(){
    return {
		
    }
  },
  computed:{
    ...mapGetters({
	
    })
  },
  filters:{
    
  },
  methods:{
	
  },
  mounted(){
	  
  },
  watch:{
   
  },
}
</script>

<style scoped>



</style>







