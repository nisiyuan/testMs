
export const SET_SUBJECTS = 'SET_SUBJECTS'
export const CHANGE_CUR_SUBJECT = 'CHANGE_CUR_SUBJECT'
export const SET_QUES = 'SET_QUES'
export const SET_CUR_QUES = 'SET_CUR_QUES'