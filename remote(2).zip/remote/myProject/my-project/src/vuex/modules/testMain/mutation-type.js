
export const SET_TESTS = 'SET_TESTS'