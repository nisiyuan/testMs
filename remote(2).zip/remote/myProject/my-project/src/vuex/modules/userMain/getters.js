export const getAllUserInfo = state => state.allUserInfo
export const getCurModel = state => state.curModel
export const getTeacherErrMsg = state => state.teacherErrMsg