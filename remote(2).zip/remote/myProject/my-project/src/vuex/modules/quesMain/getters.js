export const getSubjects = state => state.subjects
export const getCurSub = state => state.curSub
export const getAllQues = state => state.allQues
export const getCurQues = state => state.curQues